# Assessment and source-compliance checklist

## Important missing inputs
The current uploaded files available in this task are `SDAUR.zip` and `supermarket_sales.csv`. No separate project report template, evaluation rubric, or additional instructor instruction file was present. Consequently, this is a **provisional academic report format**, not a claim of exact compliance with a template that was not supplied. Please add the instructor's report format and rubric for a final structure-by-structure reconciliation.

## Checklist derived from the explicit instructions in the prompt
- [x] Dataset has at least 500 observations (1,000 rows).
- [x] Dataset has at least 10 variables (17 columns).
- [x] Dataset suitability and limitations documented; no fabricated observations or columns.
- [x] At least five distinct problem statements (seven included).
- [x] Unit I–IV mapping references actual course material filenames and project scripts.
- [x] Code uses relative paths and a main R entry point.
- [x] Graphs include titles, axis labels and report inferences.
- [x] Outputs and summary tables are included.
- [x] Oral examination Q&A and key function explanations included.
- [x] Student, roll number, institution, guide and signatures left as placeholders.
- [ ] Exact instructor report-template match: cannot verify because template was not uploaded.
- [ ] Rubric marks distribution and criterion-by-criterion scoring: cannot verify because rubric was not uploaded.
- [ ] R runtime execution: not performed because `Rscript` is not installed in the current environment.

## Dataset caveats to mention during viva
- `gross margin percentage` is constant (4.761905) and should not be treated as a variable explaining differences.
- `Tax 5%` equals `gross income` in the supplied rows; `gross income` is approximately 5% of `cogs`. These are accounting-derived values, not independent predictors.
- `Total` is constructed from `cogs` plus tax; regressions involving `Total`, `cogs`, and `gross income` can be mechanically strong and should not be presented as causal findings.
- `Branch` and `City` correspond one-to-one in this dataset; including both in a model would duplicate information.
- The dates span 1 January to 30 March 2019 only; monthly comparisons describe this period and do not establish a long-term trend or seasonality.
- There are no missing values and no exact duplicate rows in the supplied CSV.
