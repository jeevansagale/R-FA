# PROBLEM STATEMENTS: SUPERMARKET SALES
# Run after unit1.R and unit2.R; uses supermarket_data, sales_clean, project_root.
# Every result is based on the supplied CSV; no rows or columns are fabricated.

cat("\\n[PROBLEM STATEMENTS] Running seven distinct questions\\n")

# PS1. Which product lines generate the greatest total revenue?
ps1 <- sales_clean %>% dplyr::group_by(`Product line`) %>%
  dplyr::summarise(Transactions=dplyr::n(), Revenue=sum(Total),
                   Mean_Total=mean(Total), Mean_Rating=mean(Rating), .groups="drop") %>%
  dplyr::arrange(dplyr::desc(Revenue))
write.csv(ps1,file.path(project_root,"outputs/reports/ps1_product_line_revenue.csv"),row.names=FALSE)

# PS2. How do the branches compare in total revenue and average invoice amount?
ps2 <- sales_clean %>% dplyr::group_by(Branch,City) %>%
  dplyr::summarise(Transactions=dplyr::n(),Revenue=sum(Total),Mean_Total=mean(Total),.groups="drop")
write.csv(ps2,file.path(project_root,"outputs/reports/ps2_branch_comparison.csv"),row.names=FALSE)
ps2_anova <- stats::aov(Total ~ Branch, data=sales_clean)
capture.output(summary(ps2_anova),file=file.path(project_root,"outputs/reports/ps2_branch_anova.txt"))

# PS3. Do Member and Normal customers have different average invoice totals?
ps3 <- sales_clean %>% dplyr::group_by(`Customer type`) %>%
  dplyr::summarise(N=dplyr::n(),Mean_Total=mean(Total),Median_Total=median(Total),.groups="drop")
write.csv(ps3,file.path(project_root,"outputs/reports/ps3_customer_type.csv"),row.names=FALSE)
ps3_test <- stats::t.test(Total ~ `Customer type`, data=sales_clean)
capture.output(ps3_test,file=file.path(project_root,"outputs/reports/ps3_customer_type_t_test.txt"))

# PS4. How are transactions distributed across payment methods, and do mean totals differ?
ps4 <- sales_clean %>% dplyr::group_by(Payment) %>%
  dplyr::summarise(N=dplyr::n(),Revenue=sum(Total),Mean_Total=mean(Total),.groups="drop")
write.csv(ps4,file.path(project_root,"outputs/reports/ps4_payment_method.csv"),row.names=FALSE)
ps4_anova <- stats::aov(Total ~ Payment, data=sales_clean)
capture.output(summary(ps4_anova),file=file.path(project_root,"outputs/reports/ps4_payment_anova.txt"))

# PS5. How strongly is quantity associated with invoice total?
ps5_cor <- cor.test(sales_clean$Quantity,sales_clean$Total,method="pearson")
capture.output(ps5_cor,file=file.path(project_root,"outputs/reports/ps5_quantity_total_correlation.txt"))
ps5_model <- lm(Total ~ Quantity + `Unit price`, data=sales_clean)
capture.output(summary(ps5_model),file=file.path(project_root,"outputs/reports/ps5_invoice_total_model.txt"))

# PS6. What does the rating distribution show, and is rating linearly associated with total?
ps6 <- data.frame(Mean_Rating=mean(sales_clean$Rating),Median_Rating=median(sales_clean$Rating),
                  SD_Rating=sd(sales_clean$Rating),Min_Rating=min(sales_clean$Rating),Max_Rating=max(sales_clean$Rating))
write.csv(ps6,file.path(project_root,"outputs/reports/ps6_rating_summary.csv"),row.names=FALSE)
ps6_cor <- cor.test(sales_clean$Rating,sales_clean$Total)
capture.output(ps6_cor,file=file.path(project_root,"outputs/reports/ps6_rating_total_correlation.txt"))

# PS7. How does revenue vary across the available months and weekdays?
sales_clean$Month <- format(sales_clean$Date,"%Y-%m")
sales_clean$Weekday <- weekdays(sales_clean$Date)
ps7_month <- sales_clean %>% dplyr::group_by(Month) %>% dplyr::summarise(N=dplyr::n(),Revenue=sum(Total),Mean_Total=mean(Total),.groups="drop")
write.csv(ps7_month,file.path(project_root,"outputs/reports/ps7_monthly_revenue.csv"),row.names=FALSE)
ps7_day <- sales_clean %>% dplyr::group_by(Weekday) %>% dplyr::summarise(N=dplyr::n(),Revenue=sum(Total),Mean_Total=mean(Total),.groups="drop")
write.csv(ps7_day,file.path(project_root,"outputs/reports/ps7_weekday_revenue.csv"),row.names=FALSE)

cat("[PROBLEM STATEMENTS] Completed. Review outputs/reports/ps* and outputs/plots/.\\n")
