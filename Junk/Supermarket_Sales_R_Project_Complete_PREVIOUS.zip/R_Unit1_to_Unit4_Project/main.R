# ==============================================================================
# MAIN ENTRY POINT: R UNIT 1 TO UNIT 4 PROJECT
# Open R_Unit1_to_Unit4_Project.Rproj in RStudio, then run this file.
# ==============================================================================

cat("\n============================================================\n")
cat("R PROGRAMMING PROJECT: UNIT 1 TO UNIT 4\n")
cat("Dataset: Supermarket Sales\n")
cat("Execution order: Unit 1 -> Unit 2 -> Unit 3 -> Unit 4 -> Integrated Analysis\n")
cat("============================================================\n")

# This project expects the working directory to be the project root. When opened
# from the .Rproj file, RStudio sets this automatically.
project_root <- getwd()

required_paths <- c(
  "data/supermarket_sales.csv",
  "scripts/unit1.R",
  "scripts/course_concept_demos.R",
  "scripts/unit2.R",
  "scripts/unit3.R",
  "scripts/unit4.R",
  "scripts/data_analysis.R",
  "scripts/problem_statements.R",
  "functions/helper_functions.R",
  "requirements.R"
)
missing_paths <- required_paths[!file.exists(file.path(project_root, required_paths))]
if (length(missing_paths) > 0) {
  stop(
    paste0(
      "Required project file(s) not found relative to: ", project_root, "\n",
      paste(missing_paths, collapse = "\n"),
      "\nOpen R_Unit1_to_Unit4_Project.Rproj in RStudio and run main.R again."
    )
  )
}

# Load/install packages through the separate requirements file.
source(file.path(project_root, "requirements.R"), local = .GlobalEnv)
library(dplyr)
library(ggplot2)
library(tidyr)

# Create output directories if a user deleted them.
dir.create(file.path(project_root, "outputs", "plots"),
           recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(project_root, "outputs", "reports"),
           recursive = TRUE, showWarnings = FALSE)

# Load shared helper functions.
source(file.path(project_root, "functions", "helper_functions.R"),
       local = .GlobalEnv)

# Import CSV with a project-relative path.
dataset_path <- file.path(project_root, "data", "supermarket_sales.csv")
cat("\nLoading dataset:", dataset_path, "\n")
supermarket_data <- read.csv(dataset_path, stringsAsFactors = FALSE,
                             check.names = FALSE)

if (nrow(supermarket_data) == 0 || ncol(supermarket_data) == 0) {
  stop("The CSV was loaded but contains no rows or columns.")
}

cat("Dataset loaded successfully:", nrow(supermarket_data), "rows and",
    ncol(supermarket_data), "columns.\n")

# Execute all units in the required order. The scripts use shared objects and
# helper functions created above and in earlier unit scripts.
script_sequence <- c(
  "scripts/unit1.R",
  "scripts/course_concept_demos.R",
  "scripts/unit2.R",
  "scripts/unit3.R",
  "scripts/unit4.R",
  "scripts/data_analysis.R",
  "scripts/problem_statements.R"
)

for (script_relative_path in script_sequence) {
  cat("\n------------------------------------------------------------\n")
  cat("Running:", script_relative_path, "\n")
  cat("------------------------------------------------------------\n")
  source(file.path(project_root, script_relative_path), local = .GlobalEnv)
}

cat("\n============================================================\n")
cat("PROJECT RUN FINISHED\n")
cat("Review tables in outputs/reports/ and plots in outputs/plots/.\n")
cat("============================================================\n")
