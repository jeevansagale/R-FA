# Oral examination preparation: simple answers

1. **What is the project about?** It analyzes 1,000 supermarket transactions to compare product lines, branches, customer types and payment methods, and to examine quantity, rating and time-period patterns.
2. **Why did you choose this dataset?** It has 1,000 observations and 17 variables, exceeding the minimum row and column requirements.
3. **What is an observation?** One row, representing one recorded invoice/transaction.
4. **What is a variable?** A column such as Branch, Quantity, Total or Rating.
5. **Why inspect `str()` and `summary()`?** `str()` shows column types and structure; `summary()` gives quick descriptive summaries.
6. **What does `read.csv()` do?** Imports a CSV file into R as a data frame.
7. **Why use `as.Date()`?** To convert date text into a date object so dates can be grouped or ordered correctly.
8. **What does `is.na()` do?** It identifies missing values. `colSums(is.na(data))` counts missing values in each column.
9. **What is a duplicate check?** `duplicated(data)` flags rows identical to earlier rows. Duplicate-like records should be investigated before deleting.
10. **What does `select()` do?** Chooses columns.
11. **What does `filter()` do?** Chooses rows satisfying conditions.
12. **What does `mutate()` do?** Creates or transforms columns.
13. **What do `group_by()` and `summarise()` do?** Group rows by categories and calculate summaries for each group.
14. **Mean vs median?** Mean is the arithmetic average; median is the middle value and is less affected by extreme values.
15. **What is standard deviation?** A measure of how spread out values are around the mean.
16. **What is IQR?** The third quartile minus the first quartile; spread of the middle 50% of values.
17. **What is correlation?** A measure of direction and strength of a linear association, from -1 to +1. It does not establish causation.
18. **What does `lm()` do?** Fits a linear regression model.
19. **What does R-squared mean?** The proportion of response-variable variation explained by the fitted model in the sample.
20. **What is a p-value?** Under a specified null hypothesis and model assumptions, it measures how unusual the observed statistic (or more extreme) would be if the null were true. It is not the probability the null is true.
21. **Why use ANOVA?** To test whether three or more group means differ overall. A significant result would not by itself say which groups differ.
22. **What does the customer-type test show?** The Member and Normal mean invoice totals are close, and the Welch t-test is not statistically significant at the 5% level in this dataset.
23. **What is the strongest practical relationship found?** Quantity and invoice total are positively associated (Pearson r about 0.706), which is partly expected because invoice total is based on quantity and unit price.
24. **Why is COGS vs gross income not an independent discovery?** Gross income is calculated from COGS at a 5% rate in these data, so the near-perfect association is built into the accounting formula.
25. **What are the project limitations?** It is a limited three-month sample from three branches; ratings and sales are observational; results may not generalize to other stores or periods.
26. **Why are names left blank?** Team and institutional details were not provided, so placeholders avoid inventing them.
27. **How do you run the project?** Open the `.Rproj` file in RStudio and run `main.R` from the project root; required packages are checked by `requirements.R`.
28. **Has the R code been executed here?** No. This environment did not have an R/Rscript runtime, so static checks and independent calculations from the CSV were done, but the full R execution must be verified in RStudio.

## Important functions at a glance
- `c()` combine values; `:` create an integer sequence; `matrix()` create a matrix; `data.frame()` create a data frame.
- `dim()`, `names()`, `str()`, `summary()` inspect data.
- `mean()`, `median()`, `sd()`, `var()`, `quantile()`, `IQR()` summarize numerical data.
- `cor()` and `cor.test()` calculate correlation and test its null hypothesis.
- `ggplot()` starts a plot; `geom_col()` draws precomputed bars; `geom_bar()` counts rows; `geom_histogram()` displays a distribution; `geom_boxplot()` compares spread; `geom_point()` draws a scatterplot; `labs()` adds labels.
- `aov()` fits an analysis-of-variance model; `t.test()` compares two means; `lm()` fits linear regression; `predict()` makes model-based predictions; `confint()` returns coefficient confidence intervals.
