# Unit I–IV mapping to the supermarket project

This mapping is based on the actual files inside `SDAUR.zip`. Several PDFs (`datatype_change (1).pdf`, `data_join.pdf`, `Missing_value.pdf`, `SDAUR Unit II R scipt.pdf`, and `wrangling using tidyr (1).pdf`) had little or no extractable text in automated PDF extraction; their filenames are preserved in the source inventory, but exact examples inside image-only pages could not all be independently verified. The mapping below therefore distinguishes clearly visible topics from reasonable dataset adaptations.

| Unit | Verified topic/concept | Project implementation |
|---|---|---|
| I | Arithmetic, vectors, scalar/vector operations, basic functions, types/mode/attributes, matrices and indexing, data frames, binding, CSV import/export, `str`, `summary` | `scripts/unit1.R`; dataset profile and export |
| II | Missing-value checks; descriptive statistics; `dplyr` select/filter/mutate/slice/arrange/group_by/summarise; plotting examples (bar, box, histogram, scatter, density, violin, pie); `tidyr`/type-change topics by file name | `scripts/unit2.R`, `scripts/problem_statements.R` |
| III | Scatterplot, correlation, simple linear regression, model summary, prediction and regression-line plotting | `scripts/unit3.R` |
| IV | Multiple regression example, numeric correlation, boxplots/outlier inspection, model summary and prediction | `scripts/unit4.R`, `scripts/problem_statements.R` |

Some Unit I matrix operations, joins, wide/long reshaping, and missing-value replacement do not naturally answer the primary supermarket questions. They are demonstrated in `scripts/course_concept_demos.R` using tiny, explicitly separate teaching examples that are never mixed into the supplied dataset. The CSV itself has no missing values, so the missing-value audit is still reported and the handling method is demonstrated separately. Pie/violin examples are not forced into the primary findings where they add little analytical value.
