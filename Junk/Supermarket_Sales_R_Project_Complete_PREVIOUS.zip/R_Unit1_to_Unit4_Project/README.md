# Supermarket Sales R Project (Units I–IV)

## Contents
- `R_Unit1_to_Unit4_Project.Rproj`: open this in RStudio.
- `main.R`: main entry point.
- `data/supermarket_sales.csv`: supplied dataset, preserved without edits.
- `scripts/unit1.R` to `scripts/unit4.R`: unit-based course implementations.
- `scripts/course_concept_demos.R`: separate tiny teaching examples for matrix operations, joins, tidyr reshaping, factor conversion and missing values (not mixed into the sales dataset).
- `scripts/problem_statements.R`: seven distinct project questions and tests.
- `scripts/data_analysis.R`: integrated summaries and plots.
- `outputs/plots/`: figures made from the actual supplied CSV for report insertion; R scripts regenerate their corresponding figures when run.
- `outputs/reports/`: CSV/TXT summaries, data-quality audits, inferential test results and Unit mapping.
- `report/final_project_report.docx` and `.pdf`: editable/print-ready provisional report.
- `oral_exam/viva_questions_and_functions.md`: viva prep.
- `reference_materials/original_SDAUR/`: supplied course materials.

## Dataset suitability
The CSV contains 1,000 rows and 17 columns, with six meaningful categorical grouping variables and eight numeric variables (one numeric field, gross margin percentage, is constant). It meets the minimum 500 rows and 10 variables. No missing values or exact duplicate rows were found. The source data was not modified.

## Run in RStudio
1. Install R and RStudio.
2. Open `R_Unit1_to_Unit4_Project.Rproj`.
3. Open `main.R` and run the whole script. Run from the project root.
4. `requirements.R` checks for `dplyr`, `ggplot2`, and `tidyr` and installs any missing packages.
5. Inspect `outputs/plots/` and `outputs/reports/`.

## Important execution note
R/Rscript was not available in the environment used to prepare these files, so the R scripts have **not** been executed end-to-end here. The dataset was independently analyzed to generate the included reference plots/tables and to populate the report. Run `main.R` in RStudio and resolve any environment-specific errors before submission. Do not claim a successful R run until that test passes.

## Missing instructor files
Only `SDAUR.zip` and `supermarket_sales.csv` were available. A separate instructor report template, evaluation rubric, and additional instruction files were not uploaded. The included report follows a conventional college-project structure and is explicitly provisional; exact compliance cannot be verified until those files are provided.

## Interpretation cautions
- `gross margin percentage` is constant.
- `Tax 5%` equals `gross income` in the supplied data; `gross income` is derived from COGS at 5%.
- `Total` is derived from COGS plus tax, so regression involving these variables is partly mechanical.
- Branch and City correspond one-to-one.
- Dates cover only 1 January to 30 March 2019.
