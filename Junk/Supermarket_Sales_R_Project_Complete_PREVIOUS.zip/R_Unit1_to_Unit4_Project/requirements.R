# requirements.R
# Run this file once if any required package is not installed.
# Packages are limited to those used in the project and taught in SDAUR.
required_packages <- c("dplyr", "ggplot2", "tidyr")

missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  install.packages(missing_packages, repos = "https://cloud.r-project.org")
}

cat("Required packages are available:\n")
for (package_name in required_packages) {
  cat(" - ", package_name, "\n", sep = "")
}
